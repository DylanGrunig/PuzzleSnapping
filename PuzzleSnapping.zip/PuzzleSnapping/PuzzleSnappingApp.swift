//
//  PuzzleSnappingApp.swift
//  PuzzleSnapping
//
//  Created by Dylan Grunig on 3/8/23.
//

import SwiftUI

@main
struct PuzzleSnappingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
