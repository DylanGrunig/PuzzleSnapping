
//import SwiftUI
//
//struct ContentView: View {
//var body: some View {
//    ZStack {
//
//        DragableImage(imageName: "1")
//         .position(x: CGFloat.random(in:
//           0...UIScreen.main.bounds.width-300),
//                  y: CGFloat.random(in:
//                      0...UIScreen.main.bounds.height-400))
//                DragView(imageName: "2")
//                .position(x: CGFloat.random(in:
//                   0...UIScreen.main.bounds.width-300),
//                          y: CGFloat.random(in:
//                              0...UIScreen.main.bounds.height-400))
//                DragView(imageName: "3")
//                .position(x: CGFloat.random(in:
//                   0...UIScreen.main.bounds.width-300),
//                          y: CGFloat.random(in:
//                              0...UIScreen.main.bounds.height-400))
//                DragView(imageName: "4")
//                .position(x: CGFloat.random(in:
//                   0...UIScreen.main.bounds.width-300),
//                          y: CGFloat.random(in:
//                              0...UIScreen.main.bounds.height-400))
//                DragView(imageName: "5")
//                .position(x: CGFloat.random(in:
//                   0...UIScreen.main.bounds.width-300),
//                          y: CGFloat.random(in:
//                              0...UIScreen.main.bounds.height-400))
//                DragView(imageName: "6")
//                .position(x: CGFloat.random(in:
//                   0...UIScreen.main.bounds.width-300),
//                          y: CGFloat.random(in:
//                              0...UIScreen.main.bounds.height-400))
//                DragView(imageName: "7")
//                .position(x: CGFloat.random(in:
//                   0...UIScreen.main.bounds.width-300),
//                          y: CGFloat.random(in:
//                              0...UIScreen.main.bounds.height-400))
//                DragView(imageName: "8")
//                .position(x: CGFloat.random(in:
//                   0...UIScreen.main.bounds.width-300),
//                          y: CGFloat.random(in:
//                              0...UIScreen.main.bounds.height-400))
//                DragView(imageName: "9")
//                .position(x: CGFloat.random(in:
//                   0...UIScreen.main.bounds.width-300),
//                          y: CGFloat.random(in:
//                              0...UIScreen.main.bounds.height-400))
//
//                }
//                .padding()
//            }
//        }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}
